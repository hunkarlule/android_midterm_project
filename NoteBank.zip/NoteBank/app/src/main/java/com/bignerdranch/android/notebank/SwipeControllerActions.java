package com.bignerdranch.android.notebank;

public abstract class SwipeControllerActions {

    public void onLeftClicked(int position) {
    }

    public void onRightClicked(int position) {
    }

}